/**
 * Created by mirajo on 11/13/14.
 */

$(document).ready(function() {

    $("body").wallpaper({
    source:{
        poster: "img/poster.png",
        video: "//www.youtube.com/embed/mVZgznViBGA"

        }

    });
    console.log("Video background");
});

//<script src="includes/wpbg.js"></script>
//<script src="jquery.fs.wallpaper.js"></script>
//<link href="jquery.fs.wallpaper.css" rel="stylesheet"/>